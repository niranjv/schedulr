library(testthat)
library("TestGcov")

test_check("TestGcov")
