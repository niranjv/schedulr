library(testthat)
library("TestS4")

test_check("TestS4")
