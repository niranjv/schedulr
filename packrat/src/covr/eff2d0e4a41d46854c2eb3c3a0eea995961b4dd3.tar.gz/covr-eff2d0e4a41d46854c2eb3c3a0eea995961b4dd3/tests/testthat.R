library(testthat)
library("covr")

test_check("covr")
